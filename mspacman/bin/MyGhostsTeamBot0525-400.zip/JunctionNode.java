//package controllers.MyController;

//package controllers;

import core.*;

import java.util.*;

public class JunctionNode {
	
	public ArrayList<JunctionNode> adjJunc;
	int[] dirs2Adj;
	int[] dirs4Adj;
	
	public Node node;
		
	public JunctionNode(Node node){
		this.node = node;
		adjJunc = new ArrayList<JunctionNode>();
		dirs2Adj = new int[node.adj.size()];
		dirs4Adj = new int[node.adj.size()];
	}
	
	public String toString(){
		return node.toString();
	}
	
}
