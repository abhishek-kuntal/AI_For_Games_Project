//package controllers.MyController;

//package controllers;

import competition.*;
import core.*;
import core.maze.*;

//import java.lang.reflect.Method;
import java.util.*;

import controllers.EuclideanScore;
import controllers.ManhattanScore;
import controllers.NodeScore;
import controllers.PathScore;
import controllers.RandScore;

public class MCTThread extends Thread implements Constants{
	private static final int maxVisitTimes = 1000;
	private static final int visitThres = 1;
	
	private interface NodeScore {
		double score(SimGameState gs, Node node);
	}
	
	private final NodeScore[] scorers = new NodeScore[] {
			new NodeScore(){public double score(SimGameState gs, Node node){return PathScore(gs, node);}},
			new NodeScore(){public double score(SimGameState gs, Node node){return EuclideanScore(gs, node);}},
			new NodeScore(){public double score(SimGameState gs, Node node){return MahattanScore(gs, node);}},
			new NodeScore(){public double score(SimGameState gs, Node node){return PathScore(gs, node);}},
	};
	GameStateInterface gsi;
	TreeNode root;
	MyGhostsTeamBot gTeam;
	KNNAgent pseudoAgent = null;
	final int gId;
	
	boolean alive;
	
	public MCTThread(GameStateInterface gsi, TreeNode root, int gId, MyGhostsTeamBot gTeam) {
		this.gsi = gsi;
		this.root = root;
		this.gTeam = gTeam;
		this.gId = gId;
		alive = true;
	}
	
	public MCTThread(GameStateInterface gsi, TreeNode root, int gId, KNNAgent pseudoAgent, MyGhostsTeamBot gTeam) {
		this.gsi = gsi;
		this.root = root;
		this.gTeam = gTeam;
		this.gId = gId;
		this.pseudoAgent = pseudoAgent;
		alive = true;
	}
	
	public synchronized void die() {
		alive = false;
	}
	
	public void run() {
		while(alive && root != null && root.nVisits < maxVisitTimes){
			//ElapsedTimer t = new ElapsedTimer();
			if (!gTeam.mainThread.isAlive()) {
				break;
			}
			//GameStateInterface gs = gsi.copy();
			SimGameState gs = TreeNode.getStartState(gTeam.trees, gsi.copy(), gId, pseudoAgent);
			if (root.node.node != gs.getGhosts()[gId].current || root.dir2Parent != (gs.getGhosts()[gId].curDir + 2) % 4) {
				root.nVisits++;
				continue;
			}
			if (gs.MsPacManDeath() || gs.terminal() || gs.getPills().isEmpty() && gs.getPowers().isEmpty()){
				root.nVisits++;
				continue;
			}
			LinkedList<TreeNode> visited = root.selectedNodes();
			TreeNode lastNode = visited.get(visited.size()-1); 
			if (lastNode == null) continue;
			if (lastNode.nVisits > visitThres || lastNode == root){
				lastNode.expand(gs.getMaze(),gTeam.juncs);
				visited.add(lastNode.select());
			}
			int i;
	        List<TreeNode>[] trees = (List<TreeNode>[]) new List[nGhosts];
	        for (i = 0; i < nGhosts; i++){
	        	if(i == gId) trees[i] = visited;
	        	else {
	        		trees[i] = gTeam.trees[i];
	        		//trees[i] = null;
	        	}
	        }
	        if(pseudoAgent != null) pseudoAgent.reset();
	        SimGameState result = root.simGame(trees, gs, pseudoAgent);
	        double value = result.getScore();
	        int time = result.getTotalGameTicks();
	        /*
	        double dist = 1;
	        for (i = 0; i < nGhosts; i++){
	        	double sc = scorers[i].score(result, result.getGhosts()[i].current);
	        	if (result.getGhosts()[i].edible()) dist += (sc > 500)? 0 : 500 - sc;
	        	else dist += sc;
	        }
	        */
	        //dist = 1;
	        i = root.disNode < 0? -root.disNode - 1 : visited.size();
	        //int j = i > 3 ? 1 : 0;
	        //j = i/2 - 1;
	        //ListIterator<TreeNode> liVisited = visited.listIterator(j);
	        for (TreeNode node : visited) {
	            // would need extra logic for n-player game
	            // System.out.println(node);
	            node.updateStats(value, time, root);
	            if (root.disNode < 0 && (i--) < 0) break;
	        }
	        //System.out.println (t);
	        /*
	        while (liVisited.hasPrevious()){
	        	liVisited.previous().updateStats(root);
	        }
	        */
	        
	    }
		//System.out.println("MCTThread " + Thread.currentThread().getName());
	}
	
	double PathScore(SimGameState gs, Node node) {
        return gs.getMaze().dist(gs.getPacman().current, node);
    }
	
	double EuclideanScore(SimGameState gs, Node node) {
        Node pac = gs.getPacman().current;
        return Math.sqrt(sqr(node.x - pac.x) + sqr(node.y - pac.y));
    }
	
	private static double sqr(double x) {
        return x * x;
    }
	
	double MahattanScore(SimGameState gs, Node node) {
		Node pac = gs.getPacman().current;
	    return Math.abs(node.x - pac.x) + Math.abs(node.y - pac.y);
	}
}
