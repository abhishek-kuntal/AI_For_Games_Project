//package controllers.MyController;

//package controllers;

//import competition.*;
import core.*;
//import core.utilities.Utilities;
//import controllers.*;

import java.util.*;

public class MCTDummyTeam implements SimGhostsController, Constants {
	
	List<TreeNode>[] trees ;
	int[] treeCur;
	private final int[] dirs;
    //private final NodeScore[] scorers;
    //private final ArrayList<Node> options;
	Node pres[];
	
	public MCTDummyTeam(List<TreeNode>[] trees) {
		this.trees = trees;
		dirs = new int[nGhosts];
		treeCur = new int[nGhosts];
		pres = new Node[nGhosts];
		/*
		options = new ArrayList<Node>();
        scorers = new NodeScore[]{
                new PathScore(), new EuclideanScore(),
                new ManhattanScore(), new PathScore(),
        };
        */
	}
	
	@Override
	public int[] getActions(SimGameState gs) {
		
		for (int i=0; i<nGhosts; i++) {
			/*
			if (i == 0){
				Ghosts gh = gs.getGhosts()[i];
	            options.clear();
	            for (Node n : gh.current.adj) {
	                if (!n.equals(gh.previous)) options.add(n);
	            }
	            if (!gh.edible() || gh.edibleTime < gs.getMaze().dist(gh.current, gs.getPacman().current) / 3.0 )
	            	dirs[i] = Utilities.getMinDir(options, gh.current, scorers[i], gs);
	            else 
	            	dirs[i] = getMaxDir(options, gh.current, scorers[i], gs);
	            continue;
			}
			*/
			if ( i == 0 ){
				dirs[i] = NEUTRAL;
				continue;
			}
			
			if (trees[i] == null || treeCur[i] < 0 || trees[i].size() <= treeCur[i] + 1) {
				dirs[i] = rand.nextInt(dx.length);
			} else {
				if (gs.getGhosts()[i].current == trees[i].get(treeCur[i] + 1).node.node) {
					treeCur[i]++;
				}
				// If the ghost reverse direction, move randomly
				if (pres[i] == gs.getGhosts()[i].current || gs.getGhosts()[i].returning()) {
					dirs[i] = rand.nextInt(dx.length);
					//treeCur[i] = trees[i].size();
					treeCur[i] = -treeCur[i] - 1;
				}
				else if (trees[i].size() > treeCur[i] + 1) dirs[i] = trees[i].get(treeCur[i] + 1).dir4Parent;
				pres[i] = gs.getGhosts()[i].previous;
			}
		}
		return dirs;
	}
	
	/*
	private int getMaxDir(ArrayList<Node> nodes, Node cur, NodeScore f, GameStateInterface gs){
		double best = Double.MIN_VALUE;
        // selected current
        Node sel = null;
        for (Node n : nodes) {
            if (f.score(gs, n) > best) {
                best = f.score(gs, n);
                sel = n;
            }
        }
        if (sel == null) return NEUTRAL;
        return Utilities.getWrappedDirection(cur,sel,gs.getMaze());
	}
	*/
}
